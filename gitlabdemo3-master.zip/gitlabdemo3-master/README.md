# spring-app

This app is used for demo purposes to show GitLab Auto DevOps. Please do not change the files in this repository without consulting tmm_at_gitlab_dot_com first.
